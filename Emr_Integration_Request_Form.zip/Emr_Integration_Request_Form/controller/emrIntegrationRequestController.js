const EmrIntegrationRequest = require('../models/emrIntegrationRequest');

const addEmrIntegrationRequest = async (req, res) => {
  try {
    const form = new EmrIntegrationRequest(req.body);
    await form.save();
    res.status(201).json({ message: 'Request added successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Internal Server Error', error: error.message });
  }
}

const getEmrIntegrationRequests = async (req, res) => {
  try {
    let { page, size, lab } = req.query;
    
    page = page ? parseInt(page) : 1;
    size = size ? parseInt(size) : 9;

    const limit = size;
    const skip = (page - 1) * limit;

    const matchStage = {};
    if (lab) matchStage.lab = lab;

    const aggregationPipeline = [
      { $match: matchStage },
      { $sort: { _id: 1 } },
      { $skip: skip },
      { $limit: limit },
      { $group: {
        _id: "$lab",
        count: { $sum: 1 },
        documents: { $push: "$$ROOT" }
      }},
      { $project: {
        lab: "$_id",
        count: 1,
        documents: 1
      }}
    ];

    const results = await EmrIntegrationRequest.aggregate(aggregationPipeline);

    res.status(200).json({
      page,
      size,
      data: results
    });
  } catch (error) {
    res.status(500).json({
      message: "Error retrieving requests: " + error.message
    });
  }
}

const getEmrIntegrationRequest = async (req, res) => {
  const { id } = req.params;
  try {
    const request = await EmrIntegrationRequest.findById(id);
    if (!request) {
      return res.status(404).json({ message: "Request not found" });
    }
    res.status(200).json(request);
  } catch (error) {
    res.status(500).json({
      message: "Error finding request: " + error.message
    });
  }
}

const getEmrIntegrationRequestWithLab = async (req, res) => {
  try {
    const aggregationPipeline = [
      { $match: { lab: { $in: ['dlw', 'microgen'] } } },
      { $group: {
        _id: "$lab",
        count: { $sum: 1 }
      }},
      { $group: {
        _id: null,
        labs: { $push: { lab: "$_id", count: "$count" } },
        totalCount: { $sum: "$count" }
      }},
      { $project: {
        _id: 0,
        labs: 1,
        totalCount: 1
      }}
    ];
    const result = await EmrIntegrationRequest.aggregate(aggregationPipeline);

    if (result.length === 0) {
      return res.status(404).json({ message: "No documents found for the provided lab names" });
    }

    res.status(200).json(result[0]);
  } catch (error) {
    res.status(500).json({
      message: "Error finding request count: " + error.message
    });
  }
}

const deleteEmrIntegrationRequest = async (req, res) => {
  const { id } = req.params;

  try {
    const request = await EmrIntegrationRequest.findById(id);
    if (!request) {
      return res.status(404).json({ message: 'Request not found with the given ID' });
    }
    await EmrIntegrationRequest.findByIdAndDelete(id);
    res.status(200).json({ message: 'Request deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: `Error deleting request: ${error.message}` });
  }
}

const updateEMRIntegrationRequest = async (req, res) => {
  try {
    const request = await EmrIntegrationRequest.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!request) {
      return res.status(404).json({ message: 'Request not found with the given ID' });
    }
    res.status(200).json({ message: 'Request updated successfully', request });
  } catch (error) {
    res.status(400).json({ message: `Error updating request: ${error.message}` });
  }
}

const getByLab = async (req,res) =>{
  
  const {lab,client_name} = req.query;
  try{
    const getlab = await EmrIntegrationRequest.findOne({ lab,client_name});

    //const getlab = await EmrIntegrationRequest.find({ lab:'microgen'},{client_name:'XYZ Clinic'});

    // console.log(getlab);

    if( getlab){

       return res.status(200).json({getlab});
    }
    }catch(error){

      return res.status(500);
  }
}


const getEmrIntegrationRequestsLab = async (req, res) => {
  const { lab } = req.query;
  if (!lab) {
    return res.status(400).json({ message: 'Lab parameter is required' });
  }
  try {
    const startTime = Date.now();

    const documents = await EmrIntegrationRequest.find({lab});

    const endTime = Date.now();

    const timeTakenMs = endTime - startTime;

    const timeTakenSec = (timeTakenMs / 1000).toFixed(2);

    const documentCount = documents.length;

    if (documentCount === 0) {
      return res.status(404).json({ message: 'No documents found for the provided lab name' });
    }

    return res.status(200).json({
      timeTakenMs: `${timeTakenMs} ms`,
      timeTakenSec: `${timeTakenSec} seconds`,
      count: documentCount,
      documents
    });
  } catch (error) {
    return res.status(500).json({
      message: 'Error fetching documents: ' + error.message
    });
  }
}

const getEmrRequestWithDateAndLab  = async (req,res) => {

  const {lab,requested_date} = req.query;

  try {
    const DateAndLabName =  await EmrIntegrationRequest.find({lab,requested_date});

    if(!DateAndLabName){
       return res.status(400).json({
        messgae : "Nothing Found With Your Given Data"
       })
    }
     return res.status(200).json({
      DateAndLabName
     })    
  } catch (error) {
    return res.status(500).json({
      message : "Error :"+error.message
    })
    
  }

}

const insertEmrIntegrationRequest = async (req, res) => {
  try {
    const insertedUser = await EmrIntegrationRequest.create(req.body);
    if (!insertedUser) {
      return res.status(400).json({
        message: "Failed to Insert",
      });
    }

    console.log("Added Successfully");
    return res.status(200).json({
      message: "Request Added Successfully",
      data: insertedUser,
    });
  } catch (error) {
    return res.status(500).json({
      message: "Error: " + error.message,
    });
  }
};

const insertEmrIntegrationRequests = async (req, res) => {
  try {
    const insertedUser = await EmrIntegrationRequest.insertMany(req.body);
    if (!insertedUser) {
      return res.status(400).json({
        message: "Failed to Insert",
      });
    }

    console.log("Added Successfully");
    return res.status(200).json({
      message: "Request Added Successfully",
      data: insertedUser,
    });
  } catch (error) {
    return res.status(500).json({
      message: "Error: " + error.message,
    });
  }
};


module.exports = {
  getEmrIntegrationRequests,
  getEmrIntegrationRequest,
  addEmrIntegrationRequest,
  updateEMRIntegrationRequest,
  deleteEmrIntegrationRequest,
  getEmrIntegrationRequestWithLab,
  getByLab,
  getEmrIntegrationRequestsLab,
  getEmrRequestWithDateAndLab,
  insertEmrIntegrationRequest,
  insertEmrIntegrationRequests
}
