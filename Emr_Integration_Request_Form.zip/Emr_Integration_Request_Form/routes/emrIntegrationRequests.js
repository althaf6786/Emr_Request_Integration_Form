const express = require('express');
const router = express.Router();
const emrIntegrationRequestController = require('../controller/emrIntegrationRequestController'); 

router.get('/emr-integration-requests',emrIntegrationRequestController.getEmrIntegrationRequests)
router.get('/emr-integration-requests/:id',emrIntegrationRequestController.getEmrIntegrationRequest)
router.get('/emr-integration-requests-withlab',emrIntegrationRequestController.getEmrIntegrationRequestWithLab)
router.post('/emr-integration-requests',emrIntegrationRequestController.addEmrIntegrationRequest)
router.patch('/emr-integration-requests/:id',emrIntegrationRequestController.updateEMRIntegrationRequest)
router.delete('/emr-integration-requests/:id',emrIntegrationRequestController.deleteEmrIntegrationRequest)
router.get('/emr-getBy-lab' , emrIntegrationRequestController.getByLab),
router.get('/emr-integration-requsests-lab' , emrIntegrationRequestController.getEmrIntegrationRequestsLab),
router.get('/emr-integration-requsest-with-dateandlab' , emrIntegrationRequestController.getEmrRequestWithDateAndLab),
router.post('/insert-emr-Integration-Request',emrIntegrationRequestController.insertEmrIntegrationRequest),
router.post('/insert-emr-Integration-Requests',emrIntegrationRequestController.insertEmrIntegrationRequests)







module.exports = router