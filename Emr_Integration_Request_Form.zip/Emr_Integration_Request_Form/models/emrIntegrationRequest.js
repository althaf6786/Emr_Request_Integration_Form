const mongoose = require('mongoose');

const emrIntegrationRequestSchema = new mongoose.Schema({
  lab:{
    type :String,
    enum : ['dlw','microgen'],
    require:true
  },
  requested_date: {
    type: Date,
    required: true
  },
  client_name: {
    type: String,
    required: true
  },
  client_address: {
    type: String,
    required: true
  },
  client_integration_poc: {
    type: String,
    required: true
  },
  client_emr_name: {
    type: String,
    required: true
  },
  client_emr_poc_name: {
    type: String,
    required: true
  },
  client_emr_poc_designation: {
    type: String,
    required: true
  },
  client_emr_poc_phone: {
    type: String,
    required: true
  },
  client_emr_poc_email: {
    type: String,
    required: true
  },
  client_start_date:{
    type: Date,
    required: true
  },
  integration_goal_date:{
    type: Date,
    required: true
  },
  integration_approval:{
    type: String,
    required: true
  },
  integration_promise_date:{
    type: Date,
    required: true
  },
  integration_contact_person:{
    type: String,
    required: true
  },
  progress_notes:{
    type: String
  },
  completion_sign_off:{
    type:String
  },
  completion_sign_date:{
    type:Date
  },
  
});

emrIntegrationRequestSchema.index({ lab: 1  });

const emrIntegrationRequestModel = mongoose.model('EmrIntegrationRequest', emrIntegrationRequestSchema,'emr_integration_requests');

module.exports = emrIntegrationRequestModel;
