const dotenv = require('dotenv');
const express = require('express');
const mongoose = require('mongoose');
const emrIntegrationRequestsRoutes  = require('./routes/emrIntegrationRequests');

dotenv.config();

const app = express();

app.use(express.json());

app.use(emrIntegrationRequestsRoutes);

const port = process.env.PORT || 1234;

console.log(port);

mongoose.connect(process.env.MONGODB_URI)
  .then(() => {
    console.log("DB Connected Successfully");
  })
  .catch(err => {
    console.log(`DB Connection Error: ${err.message}`);
  });

app.listen(port, () => {
  console.log(`Server Running On ${port}`);
});


