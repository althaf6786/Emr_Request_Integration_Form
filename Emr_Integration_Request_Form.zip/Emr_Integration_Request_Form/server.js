const mongoose = require('mongoose');
const { faker } = require('@faker-js/faker');
const emrIntegrationRequestFaker = require('./models/emrIntegrationRequest'); 

const generateEMRIntegrationRequests = (num) => {
  const requests = [];

  for (let i = 0; i < num; i++) {
    const lab = faker.helpers.arrayElement(['dlw', 'microgen']);
    const requested_date = faker.date.past();
    const client_name = faker.company.name();
    const client_address = faker.location.streetAddress();
    const client_integration_poc = faker.person.fullName();
    const client_emr_name = faker.company.name();
    const client_emr_poc_name = faker.person.fullName();
    const client_emr_poc_designation = faker.person.jobTitle();
    const client_emr_poc_phone = faker.phone.number();
    const client_emr_poc_email = faker.internet.email();
    const client_start_date = faker.date.future();
    const integration_goal_date = faker.date.future();
    const integration_approval = faker.helpers.arrayElement(['Approved', 'Pending', 'Rejected']);
    const integration_promise_date = faker.date.future();
    const integration_contact_person = faker.person.fullName();
    const progress_notes = faker.lorem.sentences(3);
    const completion_sign_off = faker.person.fullName();
    const completion_sign_date = faker.date.future();

    requests.push({
      lab,
      requested_date,
      client_name,
      client_address,
      client_integration_poc,
      client_emr_name,
      client_emr_poc_name,
      client_emr_poc_designation,
      client_emr_poc_phone,
      client_emr_poc_email,
      client_start_date,
      integration_goal_date,
      integration_approval,
      integration_promise_date,
      integration_contact_person,
      progress_notes,
      completion_sign_off,
      completion_sign_date,
    });
  }

  return requests;
};

const emrRequests = generateEMRIntegrationRequests(100000);

const connectToDatabase = async () => {
  try {
    await mongoose.connect("mongodb+srv://krishna14054:fUc2X7kbYS37AVoe@request.2gopx0w.mongodb.net/Emr_Request")
    console.log('Database connected successfully.');
    const docs = await emrIntegrationRequestFaker.insertMany(emrRequests);

    console.log(`${docs.length} EMR integration requests have been inserted into the database.`);
  } catch (err) {
    console.error(err);
    console.error(`${err.writeErrors?.length ?? 0} errors occurred during the insertMany operation.`);
  } finally {
    mongoose.disconnect();
  }
};

connectToDatabase();
